﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace operaciones
{
    public class operaciones
    {
        int j = 0;
        int i = 0;
        public static long suma(long j, long i)
        {

            return j + i;
        }

        public static long resta(long j, long i)
        {

            return j - i;
        }

        public static long multiplicacion(long j, long i)
        {

            return j * i;
        }

        public static long division(long j, long i)
        {

            return j / i;
        }

    }
}
